import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Listout extends JFrame {
	JLabel receipt =new JLabel();
	
	public static void main(String[] args) {
		
		Listout fr = new Listout();
		centerFrame(fr);
		
		fr.setVisible(true);
	}
	private static void centerFrame(Listout fr) {
		
		
	}
	public Listout(){
		setBak(); 
		Container c = getContentPane(); 
		JPanel jp = new JPanel();
		jp.setOpaque(false); 
		setLayout(new FlowLayout());
		setSize(1024,768);
		setTitle("����");
		
		JLabel receipt =new JLabel();
		receipt.setText("�z���I�\����");
		receipt.setFont(new Font("�з���", Font.BOLD,44));
		add(receipt);
	}
	public void setBak(){
		((JPanel)this.getContentPane()).setOpaque(false);
		ImageIcon img = new ImageIcon("c://��.jpg");
		JLabel background = new JLabel(img);this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
		background.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
		}
}
